package com.devsenai1a.backendpetpagne.config;

import com.devsenai1a.backendpetpagne.security.JwtFilter;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.security.config.http.SessionCreationPolicy;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import org.springframework.security.web.SecurityFilterChain;

import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

    private final JwtFilter jwtFilter;

    public SecurityConfig(
            JwtFilter jwtFilter
    ) {

        this.jwtFilter = jwtFilter;
    }

    // =========================================
    // PASSWORD ENCODER
    // =========================================

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {

        return new BCryptPasswordEncoder();
    }

    
    
    // =========================================
    // SECURITY
    // =========================================

    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http
    ) throws Exception {

        http

            // DESABILITA CSRF
            .csrf(csrf -> csrf.disable())

            // HABILITA CORS
            .cors(cors -> {})

            // JWT = SEM SESSÃO
            .sessionManagement(session ->
                session.sessionCreationPolicy(
                    SessionCreationPolicy.STATELESS
                )
            )
            

            // ROTAS
            .authorizeHttpRequests(auth -> auth

                // PÚBLICAS
                .requestMatchers(

                    "/usuarios/**",
                    "/swagger-ui/**",
                    "/v3/api-docs/**",

                    "/uploads/**",

                    "/produtos",
                    "/produtos/**",

                    "/categorias",
                    "/categorias/**"

                ).permitAll()
                
                // ADMIN
                .requestMatchers(
                    "/produtos/admin/**"
                ).hasRole("ADMIN")

                // RESTANTE PROTEGIDO
                .anyRequest().authenticated()
            )

            // JWT FILTER
            .addFilterBefore(
                jwtFilter,
                UsernamePasswordAuthenticationFilter.class
            );
        

        return http.build();
    }
}