-- =====================================================
-- CORREÇÃO SQL: petshop_db
-- Problema: usuário gabriel@email.com tinha senha em
-- texto puro '123456'. Substituído pelo hash BCrypt.
-- Senha: 123456 → hash BCrypt abaixo
-- =====================================================

-- Atualizar senha do gabriel para hash BCrypt de '123456'
UPDATE `usuarios`
SET `senha` = '$2a$10$xJFPLRwGHIqYiJxpYtEKz.o2Vv9Z2ZHwUg6tFjTClEKPo0VqbJZFe'
WHERE `email` = 'gabriel@email.com';

-- Verificar resultado
SELECT id, nome, email, LEFT(senha,10) as senha_inicio, perfil FROM `usuarios`;
