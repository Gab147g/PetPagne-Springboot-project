-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 16/06/2026 às 20:46
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `petshop_db`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `categoria`
--

CREATE TABLE `categoria` (
  `id_categoria` int(11) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  `imagem` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `categoria`
--

INSERT INTO `categoria` (`id_categoria`, `nome`, `descricao`, `ativo`, `imagem`) VALUES
(7, 'Cachorro', 'Itens feito para o comforto de seu dog!', NULL, '/uploads/bd06726d-f6c2-4ebd-abb0-9d12cecdc729_racas-de-cachorro-golden-retriever-cpt11.jpg'),
(8, 'Sapo', 'Itens direcionados a sapos', NULL, '/uploads/19520753-942a-48d6-83bd-eff538d5e40f_my-favorite-frog-is-the-desert-rain-frog-v0-dmk5aw9za6oc1.webp'),
(9, 'Roedores', 'Itens designados aos roedores', NULL, '/uploads/2c8c6e08-ebba-474f-b1c6-b5396434a1dd_ROEDORES.jpg'),
(10, 'Pandas', 'Itens para pandas', NULL, '/uploads/dacf0f57-190f-4692-ab25-c29ea66761ff_panda.webp');

-- --------------------------------------------------------

--
-- Estrutura para tabela `itens_pedido`
--

CREATE TABLE `itens_pedido` (
  `id_item_pedido` int(11) NOT NULL,
  `id_pedido_fk` int(11) DEFAULT NULL,
  `id_produto_fk` int(11) DEFAULT NULL,
  `nome_produto` varchar(255) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `preco_unitario` decimal(38,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `itens_pedido`
--

INSERT INTO `itens_pedido` (`id_item_pedido`, `id_pedido_fk`, `id_produto_fk`, `nome_produto`, `quantidade`, `preco_unitario`) VALUES
(6, 5, NULL, 'Bambu', 5, 39.99);

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `id_pedido` int(11) NOT NULL,
  `id_usuario_fk` int(11) DEFAULT NULL,
  `data_pedido` datetime DEFAULT current_timestamp(),
  `status` varchar(255) DEFAULT NULL,
  `valor_total` decimal(38,2) DEFAULT NULL,
  `endereco_entrega` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `pedidos`
--

INSERT INTO `pedidos` (`id_pedido`, `id_usuario_fk`, `data_pedido`, `status`, `valor_total`, `endereco_entrega`) VALUES
(5, 6, '2026-06-16 15:32:20', 'PENDENTE', 199.95, 'Endereço não informado');

-- --------------------------------------------------------

--
-- Estrutura para tabela `produto`
--

CREATE TABLE `produto` (
  `id_produto` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco` decimal(38,2) DEFAULT NULL,
  `preco_desconto` decimal(38,2) DEFAULT NULL,
  `imagem` longtext DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `qtd_estoque` int(11) DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  `id_categoria` int(11) DEFAULT NULL,
  `data_criacao` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `produto`
--

INSERT INTO `produto` (`id_produto`, `nome`, `descricao`, `preco`, `preco_desconto`, `imagem`, `sku`, `qtd_estoque`, `ativo`, `id_categoria`, `data_criacao`) VALUES
(7, 'Ração golden 15kg', 'Comida bom pra cachorro!', 159.99, NULL, '/uploads/19e8fd60-091b-41b5-9f9e-38c33970d89f_racao-golden-formula-para-caes-adultos-carne-e-arroz-15-1.webp', 'RAC001', 500, 1, 7, '2026-06-16 11:53:02'),
(9, 'Bambu', 'Bambus para alimentação de pandas', 39.99, NULL, '/uploads/04b5e838-ad03-493b-9d20-bd53bbf9a304_Eduardo.jpg', 'RAC001', 300, 1, 10, '2026-06-16 15:21:55'),
(10, 'Grilo alimento vivo', 'Grilos para alimentação de anfíbios', 59.99, NULL, '/uploads/329410cb-5883-4d78-a460-19eacc12be04_grilo-o-cento.webp', 'RAC001', 100, 1, 8, '2026-06-16 15:23:58'),
(11, 'Gaiola para roedores', 'Gaiola confortavel para os roedores.', 449.99, NULL, '/uploads/80c116ec-23f7-48d2-a45d-cccbf4d98643_gaiola_hamster_multipla_27_3_ffaa998d74311ab7369d16cf5d780918.webp', 'RAC001', 50, 1, 9, '2026-06-16 15:29:41');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `perfil` varchar(255) DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `bairro` varchar(255) DEFAULT NULL,
  `complemento` varchar(255) DEFAULT NULL,
  `cep` varchar(255) DEFAULT NULL,
  `cidade` varchar(255) DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `foto` longtext DEFAULT NULL,
  `data_cadastro` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `perfil`, `endereco`, `bairro`, `complemento`, `cep`, `cidade`, `estado`, `foto`, `data_cadastro`) VALUES
(1, 'Gabriel', 'gabriel@email.com', '$2a$10$xJFPLRwGHIqYiJxpYtEKz.o2Vv9Z2ZHwUg6tFjTClEKPo0VqbJZFe', 'CLIENTE', 'Rua Exemplo', 'Centro', 'Casa', '00000-000', 'São Paulo', 'SP', 'foto_base64', '2026-05-26 08:56:26'),
(2, 'Lucas Ferreira', 'lucasferreira@email.com', '$2a$10$BnT0AtKugtamQbnvbIAkAebdfy7zkB/nsiCy8OPN4aGH03GahG3s6', 'CLIENTE', 'Rua Palmeiras, 45', 'Jardim América', 'Apartamento 12', '04567-890', 'Campinas', 'SP', 'https://i.imgur.com/user.png', '2026-05-26 11:24:42'),
(3, 'Gabriel Gerim', 'gabriel.gerim1a123@gmail.com', '$2a$10$nnvqDAM2Fx8EvRadYQLABe8I1sQ.Cem0v7SJuH9dhfKBvVFgSZqei', 'ADMIN', 'rua da mariquinhas', 'bairro das mariquinhas', '', '48194375854333', 'Votorantim', 'SP', NULL, '2026-05-28 08:23:26'),
(6, 'gg', 'gg@gmail.com', '$2a$10$.jffFMF6klGbhXuIctHBWOf63oBxbjvfUuDKgjNIB.eWlJ0TP3OqC', 'CLIENTE', 'rua das baleias', 'mar de ostra', 'Predio, 10° Andar', '46154165736735', 'São Paulo', 'SP', NULL, '2026-06-16 07:48:28');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Índices de tabela `itens_pedido`
--
ALTER TABLE `itens_pedido`
  ADD PRIMARY KEY (`id_item_pedido`),
  ADD KEY `fk_item_pedido` (`id_pedido_fk`),
  ADD KEY `fk_item_produto` (`id_produto_fk`);

--
-- Índices de tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id_pedido`),
  ADD KEY `fk_pedido_usuario` (`id_usuario_fk`);

--
-- Índices de tabela `produto`
--
ALTER TABLE `produto`
  ADD PRIMARY KEY (`id_produto`),
  ADD KEY `fk_produto_categoria` (`id_categoria`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `itens_pedido`
--
ALTER TABLE `itens_pedido`
  MODIFY `id_item_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `produto`
--
ALTER TABLE `produto`
  MODIFY `id_produto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `itens_pedido`
--
ALTER TABLE `itens_pedido`
  ADD CONSTRAINT `fk_item_pedido` FOREIGN KEY (`id_pedido_fk`) REFERENCES `pedidos` (`id_pedido`),
  ADD CONSTRAINT `fk_item_produto` FOREIGN KEY (`id_produto_fk`) REFERENCES `produto` (`id_produto`);

--
-- Restrições para tabelas `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `fk_pedido_usuario` FOREIGN KEY (`id_usuario_fk`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `produto`
--
ALTER TABLE `produto`
  ADD CONSTRAINT `fk_produto_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
