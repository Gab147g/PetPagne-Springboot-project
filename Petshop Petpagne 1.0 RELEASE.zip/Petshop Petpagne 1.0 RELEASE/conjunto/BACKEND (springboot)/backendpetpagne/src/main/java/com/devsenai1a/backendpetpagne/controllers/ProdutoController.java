package com.devsenai1a.backendpetpagne.controllers;

import com.devsenai1a.backendpetpagne.models.Produto;
import com.devsenai1a.backendpetpagne.repository.ProdutoRepository;

import com.devsenai1a.backendpetpagne.dto.ProdutoResponseDTO;

import org.springframework.data.domain.Page;

import org.springframework.data.domain.PageRequest;

import org.springframework.data.domain.Pageable;

import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
//import java.util.List;

@RestController
@RequestMapping("/produtos")
public class ProdutoController {

    private final ProdutoRepository repository;

    public ProdutoController(ProdutoRepository repository) {
        this.repository = repository;
    }
    
    private ProdutoResponseDTO converterParaDTO(Produto produto) {

        ProdutoResponseDTO dto =
                new ProdutoResponseDTO();

        dto.setId_produto(
                produto.getId_produto()
        );

        dto.setNome(produto.getNome());

        dto.setDescricao(
                produto.getDescricao()
        );

        dto.setPreco(produto.getPreco());

        dto.setQtd_estoque(
                produto.getQtd_estoque()
        );

        dto.setImagem(produto.getImagem());
        
        if (produto.getCategoria() != null) {
            dto.setId_categoria(
                produto.getCategoria().getId_categoria()
            );
        }

        return dto;
    }

    // PUBLICO
    @GetMapping
    public Page<ProdutoResponseDTO> listar(

            @RequestParam(
                    defaultValue = ""
            ) String nome,

            @RequestParam(
                    defaultValue = "0"
            ) int page,

            @RequestParam(
                    defaultValue = "10"
            ) int size
    ) {

        Pageable pageable =
                PageRequest.of(page, size);

        return repository
                .findByNomeContainingIgnoreCase(
                        nome,
                        pageable
                )
                .map(this::converterParaDTO);
    }

    // ADMIN
    @PostMapping("/admin")
    public Produto salvar(@RequestBody Produto produto) {

        produto.setData_criacao(LocalDateTime.now());

        return repository.save(produto);
    }
    
    @GetMapping("/{id}")
    public ProdutoResponseDTO buscarPorId(
            @PathVariable Integer id
    ) {

    	Produto produto = repository
    	        .findById(id)
    	        .orElseThrow();

    	return converterParaDTO(produto);
    }
    
    @PutMapping("/admin/{id}")
    public Produto atualizar(
            @PathVariable Integer id,
            @RequestBody Produto produtoAtualizado
    ) {

        Produto produto = repository.findById(id)
                .orElseThrow();

        produto.setNome(produtoAtualizado.getNome());
        produto.setDescricao(produtoAtualizado.getDescricao());

        produto.setPreco(produtoAtualizado.getPreco());

        produto.setImagem(produtoAtualizado.getImagem());

        produto.setQtd_estoque(produtoAtualizado.getQtd_estoque());

        return repository.save(produto);
    }
    
    @DeleteMapping("/admin/{id}")
    public void deletar(
            @PathVariable Integer id
    ) {

        repository.deleteById(id);
    }
}