package com.devsenai1a.backendpetpagne.repository;

import java.util.List;
import com.devsenai1a.backendpetpagne.models.Pedido;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PedidoRepository
        extends JpaRepository<Pedido, Integer> {
	
	List<Pedido> findByUsuarioId(Integer id);
}