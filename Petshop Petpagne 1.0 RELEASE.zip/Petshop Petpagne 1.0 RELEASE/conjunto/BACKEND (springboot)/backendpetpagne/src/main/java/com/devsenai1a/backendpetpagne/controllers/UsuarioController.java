package com.devsenai1a.backendpetpagne.controllers;

import com.devsenai1a.backendpetpagne.dto.LoginDTO;
import com.devsenai1a.backendpetpagne.dto.UsuarioResponseDTO;
import com.devsenai1a.backendpetpagne.models.Usuario;
import com.devsenai1a.backendpetpagne.repository.UsuarioRepository;
import com.devsenai1a.backendpetpagne.security.JwtService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    // =========================================
    // DEPENDÊNCIAS
    // =========================================

    private final UsuarioRepository repository;

    private final BCryptPasswordEncoder passwordEncoder;

    private final JwtService jwtService;

    // =========================================
    // CONSTRUTOR
    // =========================================

    public UsuarioController(

            UsuarioRepository repository,

            BCryptPasswordEncoder passwordEncoder,

            JwtService jwtService

    ) {

        this.repository = repository;

        this.passwordEncoder = passwordEncoder;

        this.jwtService = jwtService;
    }

    // =========================================
    // LISTAR USUÁRIOS
    // =========================================

    @GetMapping
    public List<UsuarioResponseDTO> listar() {

        return repository.findAll()

                .stream()

                .map(this::converterParaDTO)

                .toList();
    }

    // =========================================
    // CADASTRAR USUÁRIO
    // =========================================

    @PostMapping
    public UsuarioResponseDTO salvar(
            @RequestBody Usuario usuario
    ) {

        // DATA CADASTRO
        usuario.setData_cadastro(
                LocalDateTime.now()
        );

        // SENHA CRIPTOGRAFADA
        usuario.setSenha(
                passwordEncoder.encode(
                        usuario.getSenha()
                )
        );

        // SALVAR
        Usuario usuarioSalvo =
                repository.save(usuario);

        // RETORNAR DTO
        return converterParaDTO(
                usuarioSalvo
        );
    }

    // =========================================
    // LOGIN
    // =========================================

    @PostMapping("/login")
    public ResponseEntity<?> login(
            @RequestBody LoginDTO loginDTO
    ) {

        // BUSCAR USUÁRIO
        Optional<Usuario> usuarioOptional =
                repository.findByEmail(
                        loginDTO.getEmail()
                );

        // NÃO ENCONTRADO
        if (usuarioOptional.isEmpty()) {

            return ResponseEntity

                    .badRequest()

                    .body(
                            "Usuário não encontrado"
                    );
        }

        Usuario usuario =
                usuarioOptional.get();

        // SENHA INCORRETA
        if (!passwordEncoder.matches(

                loginDTO.getSenha(),

                usuario.getSenha()

        )) {

            return ResponseEntity

                    .badRequest()

                    .body(
                            "Senha incorreta"
                    );
        }

        // GERAR TOKEN
        String token =
                jwtService.gerarToken(
                        usuario
                );

        // RETORNAR TOKEN
        return ResponseEntity.ok(
                token
        );
    }

    // =========================================
    // CONVERTER DTO
    // =========================================

    private UsuarioResponseDTO converterParaDTO(
            Usuario usuario
    ) {

        UsuarioResponseDTO dto =
                new UsuarioResponseDTO();

        dto.setId(
                usuario.getId()
        );

        dto.setNome(
                usuario.getNome()
        );

        dto.setEmail(
                usuario.getEmail()
        );

        dto.setPerfil(
                usuario.getPerfil()
        );

        dto.setEndereco(
                usuario.getEndereco()
        );

        dto.setBairro(
                usuario.getBairro()
        );

        dto.setComplemento(
                usuario.getComplemento()
        );

        dto.setCep(
                usuario.getCep()
        );

        dto.setCidade(
                usuario.getCidade()
        );

        dto.setEstado(
                usuario.getEstado()
        );

        dto.setFoto(
                usuario.getFoto()
        );

        return dto;
    }
}