package com.devsenai1a.backendpetpagne.controllers;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.nio.file.StandardCopyOption;

import java.util.UUID;

@RestController
public class UploadController {

    @PostMapping("/upload")
    public String upload(
            @RequestParam("arquivo")
            MultipartFile arquivo
    ) throws IOException {

        // NOME ÚNICO
        String nomeArquivo =
                UUID.randomUUID()
                + "_"
                + arquivo.getOriginalFilename();

        // PASTA
        Path pastaUpload =
                Paths.get("uploads");

        // CRIAR PASTA SE NÃO EXISTIR
        Files.createDirectories(
                pastaUpload
        );

        // CAMINHO FINAL
        Path caminhoArquivo =
                pastaUpload.resolve(
                        nomeArquivo
                );

        // SALVAR
        Files.copy(
                arquivo.getInputStream(),
                caminhoArquivo,
                StandardCopyOption.REPLACE_EXISTING
        );

        // RETORNAR URL
        return "/uploads/" + nomeArquivo;
    }
}