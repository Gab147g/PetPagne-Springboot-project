package com.devsenai1a.backendpetpagne.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import com.devsenai1a.backendpetpagne.models.Produto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProdutoRepository extends JpaRepository<Produto, Integer> {

	Page<Produto> findByNomeContainingIgnoreCase(
	        String nome,
	        Pageable pageable
	);
}