package com.devsenai1a.backendpetpagne.controllers;

import com.devsenai1a.backendpetpagne.models.Categoria;
import com.devsenai1a.backendpetpagne.repository.CategoriaRepository;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/categorias")
public class CategoriaController {

    private final CategoriaRepository repository;

    public CategoriaController(CategoriaRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<Categoria> listar() {
        return repository.findAll();
    }

    @PostMapping
    public Categoria salvar(@RequestBody Categoria categoria) {
        return repository.save(categoria);
    }
    
    @PutMapping("/{id}")
    public Categoria atualizar(
            @PathVariable Integer id,
            @RequestBody Categoria categoriaAtualizada
    ) {

        Categoria categoria =
                repository.findById(id)
                        .orElseThrow();

        categoria.setNome(
                categoriaAtualizada.getNome()
        );

        categoria.setDescricao(
                categoriaAtualizada.getDescricao()
        );

        categoria.setImagem(
                categoriaAtualizada.getImagem()
        );

        return repository.save(categoria);
    }
    
    @DeleteMapping("/{id}")
    public void deletar(
            @PathVariable Integer id
    ) {

        repository.deleteById(id);
    }
    
}