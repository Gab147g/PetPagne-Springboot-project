package com.devsenai1a.backendpetpagne.controllers;

import com.devsenai1a.backendpetpagne.models.ItemPedido;
import com.devsenai1a.backendpetpagne.models.Pedido;
import com.devsenai1a.backendpetpagne.models.Usuario;

import com.devsenai1a.backendpetpagne.repository.PedidoRepository;
import com.devsenai1a.backendpetpagne.repository.UsuarioRepository;

import org.springframework.security.core.Authentication;

import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.io.IOException;

import java.util.UUID;

@RestController
@RequestMapping("/pedidos")
public class PedidoController {

    private final PedidoRepository pedidoRepository;

    private final UsuarioRepository usuarioRepository;

    public PedidoController(
            PedidoRepository pedidoRepository,
            UsuarioRepository usuarioRepository
    ) {
        this.pedidoRepository = pedidoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @GetMapping
    public List<Pedido> listar() {
        return pedidoRepository.findAll();
    }

    @PostMapping
    public Pedido criarPedido(
            @RequestBody Pedido pedido,
            Authentication authentication
    ) {


        String email = authentication.getName();

        Usuario usuario = usuarioRepository
                .findByEmail(email)
                .orElseThrow();

        pedido.setUsuario(usuario);

        pedido.setData_pedido(LocalDateTime.now());

        pedido.setStatus("PENDENTE");


        for (ItemPedido item : pedido.getItens()) {

            item.setPedido(pedido);
        }

        return pedidoRepository.save(pedido);
    }


@GetMapping("/meus")
public List<Pedido> meusPedidos(
        Authentication authentication
) {

    String email = authentication.getName();

    Usuario usuario = usuarioRepository
            .findByEmail(email)
            .orElseThrow();

    return pedidoRepository.findByUsuarioId(usuario.getId());
}

@PostMapping("/admin/upload")
public String uploadImagem(
        @RequestParam("file") MultipartFile file
) throws IOException {

    String nomeArquivo =
            UUID.randomUUID()
                    + "_"
                    + file.getOriginalFilename();

    Path caminho = Paths.get(
            "uploads",
            nomeArquivo
    );

    Files.write(
            caminho,
            file.getBytes()
    );

    return "http://localhost:8080/uploads/"
            + nomeArquivo;
}

}