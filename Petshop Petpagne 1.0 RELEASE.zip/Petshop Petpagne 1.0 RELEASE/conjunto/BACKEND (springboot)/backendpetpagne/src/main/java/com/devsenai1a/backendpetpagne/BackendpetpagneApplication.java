package com.devsenai1a.backendpetpagne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendpetpagneApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendpetpagneApplication.class, args);
	}

}
