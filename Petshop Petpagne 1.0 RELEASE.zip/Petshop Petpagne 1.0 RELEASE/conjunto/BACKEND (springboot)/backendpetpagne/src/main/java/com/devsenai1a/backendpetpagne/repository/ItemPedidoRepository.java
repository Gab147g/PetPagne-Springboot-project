package com.devsenai1a.backendpetpagne.repository;

import com.devsenai1a.backendpetpagne.models.ItemPedido;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemPedidoRepository
        extends JpaRepository<ItemPedido, Integer> {
}