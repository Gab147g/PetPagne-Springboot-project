package com.devsenai1a.backendpetpagne.repository;

import com.devsenai1a.backendpetpagne.models.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {

}