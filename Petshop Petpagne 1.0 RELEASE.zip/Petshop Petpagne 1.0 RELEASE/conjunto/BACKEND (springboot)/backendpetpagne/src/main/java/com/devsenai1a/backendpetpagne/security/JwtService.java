package com.devsenai1a.backendpetpagne.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import org.springframework.stereotype.Service;

import com.devsenai1a.backendpetpagne.models.Usuario;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;

@Service
public class JwtService {

    // =========================================
    // CHAVE JWT
    // =========================================

    private static final String SECRET_KEY =
            "minha_chave_super_secreta_petshop_123456";

    // =========================================
    // GERAR CHAVE
    // =========================================

    private Key getSigningKey() {

        return Keys.hmacShaKeyFor(
                SECRET_KEY.getBytes(StandardCharsets.UTF_8)
        );
    }

    // =========================================
    // GERAR TOKEN
    // =========================================

    public String gerarToken(
            Usuario usuario
    ) {

        return Jwts.builder()

                // EMAIL
                .setSubject(
                        usuario.getEmail()
                )

                // ROLE
                .claim(
                        "role",
                        usuario.getPerfil()
                )

                // NOME
                .claim(
                        "nome",
                        usuario.getNome()
                )

                // FOTO
                .claim(
                        "foto",
                        usuario.getFoto()
                )

                // DATA CRIAÇÃO
                .setIssuedAt(
                        new Date()
                )

                // EXPIRAÇÃO
                .setExpiration(
                        new Date(
                                System.currentTimeMillis()
                                        + 86400000
                        )
                )

                // ASSINATURA
                .signWith(
                        getSigningKey()
                )

                // FINALIZAR
                .compact();
    }

    // =========================================
    // EXTRAIR EMAIL
    // =========================================

    public String extrairEmail(
            String token
    ) {

        Claims claims = Jwts.parserBuilder()

                .setSigningKey(
                        getSigningKey()
                )

                .build()

                .parseClaimsJws(token)

                .getBody();

        return claims.getSubject();
    }

    // =========================================
    // VALIDAR TOKEN
    // =========================================

    public boolean tokenValido(
            String token
    ) {

        try {

            Jwts.parserBuilder()

                    .setSigningKey(
                            getSigningKey()
                    )

                    .build()

                    .parseClaimsJws(token);

            return true;

        } catch (Exception e) {

            return false;
        }
    }
}