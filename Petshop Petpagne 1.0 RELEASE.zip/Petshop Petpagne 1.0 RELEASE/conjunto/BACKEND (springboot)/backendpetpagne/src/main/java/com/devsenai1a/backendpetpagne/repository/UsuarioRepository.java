package com.devsenai1a.backendpetpagne.repository;

import java.util.Optional;
import com.devsenai1a.backendpetpagne.models.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {
	Optional<Usuario> findByEmail(String email);
}