package com.devsenai1a.backendpetpagne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendpetpagneApplicationTests {

	@Test
	void contextLoads() {
	}

}
